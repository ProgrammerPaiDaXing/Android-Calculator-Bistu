package com.example.cal3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {
    private Button b1;
    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;
    private Button b8;
    private Button b9;
    private Button b0;
    private Button b_equal;
    private Button b_multi;
    private Button b_divide;
    private Button b_add;
    private Button b_sub;
    private Button b_clear;
    private Button b_dot;
    private Button sin;
//    正负反转
    private Button rev;
//    开方
    private Button pow;
    private TextView t1;
    private TextView t2;
    private double val1 = Double.NaN;
    private double val2;
    private final char ADD = '+';
    private final char SUB = '-';
    private final char MUL = '*';
    private final char DIV = '/';
    private final char EQU = '=';
    private final char EXTRA = '@';
    private final char SIN = 's';
    private final char REV = 'r';
    private final char POW = '^';
    private char ACTION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idfinder();
        t2.setText("");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "1");
                    t2.setText(t2.getText().toString() + "1");
                    return;
                }

                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "1");

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "2");
                    t2.setText(t2.getText().toString() + "2");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "2");
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "3");
                    t2.setText(t2.getText().toString() + "3");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "3");
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "4");
                    t2.setText(t2.getText().toString() + "4");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "4");
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "5");
                    t2.setText(t2.getText().toString() + "5");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "5");
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "6");
                    t2.setText(t2.getText().toString() + "6");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "6");
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "7");
                    t2.setText(t2.getText().toString() + "7");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "7");
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "8");
                    t2.setText(t2.getText().toString() + "8");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "8");
            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {

                    t1.setText(t1.getText().toString() + "9");
                    t2.setText(t2.getText().toString() + "9");
                    return;
                }
                ifErrorOnOutput();
                exceedLength();
                t1.setText(t1.getText().toString() + "9");
            }
        });

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {
                    // 如果当前操作为正弦、反转或开根号，则在t1和t2上追加字符"0"
                    t1.setText(t1.getText().toString() + "0");
                    t2.setText(t2.getText().toString() + "0");
                    return;
                }
                ifErrorOnOutput();  // 检查是否有错误
                exceedLength();  // 检查是否超过文本长度限制
                t1.setText(t1.getText().toString() + "0");  // 在t1上追加字符"0"
            }
        });

        b_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t1.getText().toString().contains(".")) {
                    // 如果t1中已经包含小数点字符"."，则直接返回，不执行后续操作
                    t1.setText(t1.getText());
                    return;
                }
                exceedLength();  // 检查是否超过文本长度限制
                t1.setText(t1.getText().toString() + ".");  // 在t1上追加小数点字符"."
            }
        });


        b_divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 如果操作为 SIN、REV 或 POW
                if (ACTION == SIN || ACTION == REV || ACTION == POW)
                {
                    // 进行计算
                    calculations2();
                    // 如果结果不为整数
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "/"); // 显示结果
                    } else {
                        t2.setText((int) val1 + "/"); // 显示结果（整数形式）
                    }
                    t1.setText(null); // 清空输入
                    ACTION = DIV; // 更新操作为除法
                }
                // 如果t1中有输入
                else if (t1.getText().length() > 0) {
                    ACTION = DIV; // 更新操作为除法
                    calculations(); // 进行计算
                    // 如果结果为小数
                    if (ifReallyDecimal()) {
                        t2.setText((int) val1 + "/"); // 显示结果（整数形式）
                    } else {
                        t2.setText(val1 + "/"); // 显示结果
                    }
                    t1.setText(null); // 清空输入
                }
                // 如果t1中没有输入且t2中有内容
                else if (t1.getText().length() == 0 && t2.getText().length() > 0)
                {
                    int l = t2.getText().toString().length() - 1;
                    // 如果上一个操作是加法、除法、减法、乘法或乘方
                    if (ACTION == ADD || ACTION == DIV || ACTION == SUB || ACTION == MUL ||  ACTION == POW) {
                        t2.setText(t2.getText().toString().substring(0, l) + "/"); // 更新操作为除法
                        ACTION = DIV; // 更新操作为除法
                        return;
                    }
                    // 如果t2中最后一个字符是 ^、+、/、* 或 %
                    if (t2.getText().toString().charAt(l) == '^' || t2.getText().toString().charAt(l) == '+' || t2.getText().toString().charAt(l) == '/' || t2.getText().toString().charAt(l) == '*' || t2.getText().toString().charAt(l) == '%') {
                        t2.setText(t2.getText().toString()); // 不做任何操作
                        return;
                    }
                    t2.setText(t2.getText().toString() + "/"); // 追加除法操作符
                }
                // 如果t1中没有输入
                else if (t1.getText().length() == 0)
                {
                    t2.setText("Error"); // 显示错误消息
                }
                // 如果操作不为 '0'
                else if (ACTION != '0')
                {
                    calculations(); // 进行计算
                    // 如果结果为整数
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "/"); // 显示结果
                    } else {
                        t2.setText((int) val1 + "/"); // 显示结果（整数形式）
                    }
                    t1.setText(null); // 清空输入
                    ACTION = DIV; // 更新操作为除法
                    return;
                }
            }
        });


        sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                t2.setText("sin ");  // 在 t2 中显示 "sin "
                ACTION = SIN;  // 设置 ACTION 为 SIN（正弦函数）

                if (t1.getText().toString().isEmpty())
                    return;  // 如果 t1 中没有文本，直接返回，不执行后续操作

                calculations2();  // 执行 calculations2() 方法进行计算操作
                t2.setText("" + val1);  // 将计算结果设置为 t2 的文本内容
                ACTION = '0';  // 将 ACTION 的值设置为 '0'（空状态）
            }
        });

        rev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t2.setText("+/-"); // 设置 t2 的文本为 "+/-"
                ACTION = REV; // 设置 ACTION 为 REV

                if (t1.getText().toString().isEmpty())
                    return; // 如果 t1 中没有文本，直接返回，不执行后续操作

                calculations2(); // 执行 calculations2() 方法进行计算操作

                // 继续参与运算
                if (ACTION == ADD || ACTION == SUB || ACTION == MUL || ACTION == DIV || ACTION == POW) {
                    calculations(); // 执行计算
                }

                if (ifReallyDecimal()) {
                    t2.setText((int) val1 + ""); // 显示计算结果（整数形式）
                } else {
                    t2.setText(val1 + ""); // 显示计算结果
                }

                t1.setText("" + val1);

                ACTION = '0'; // 将 ACTION 的值设置为 '0'（空状态）
            }
        });



//        开根号
        pow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t2.setText("√"); // 设置 t2 的文本为 "√"
                ACTION = POW; // 设置 ACTION 为 POW（开根号）

                if (t1.getText().toString().isEmpty())
                    return; // 如果 t1 中没有文本，直接返回，不执行后续操作

                calculations2(); // 执行 calculations2() 方法进行计算操作

                // 继续参与运算
                if (ACTION == ADD || ACTION == SUB || ACTION == MUL || ACTION == DIV || ACTION == REV) {
                    calculations(); // 执行计算
                }

                if (ifReallyDecimal()) {
                    t2.setText((int) val1 + ""); // 显示计算结果（整数形式）
                } else {
                    t2.setText(val1 + ""); // 显示计算结果
                }

                t1.setText("" + val1);// 清空 t1 中的文本
                ACTION = '0'; // 将 ACTION 的值设置为 '0'（空状态）
            }
        });

//-----------------------------------------------------------------------------------------




        b_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {
                    // 当前操作为正弦、反转或开根号
                    calculations2();  // 执行计算
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "+");  // 显示计算结果（整数形式）加上加号
                    } else {
                        t2.setText((int) val1 + "+");  // 显示计算结果加上加号
                    }
                    t1.setText(null);  // 清空t1中的文本
                    ACTION = ADD;  // 设置操作为加法
                } else if (t1.getText().length() > 0) {
                    // t1有内容
                    ACTION = ADD;  // 设置操作为加法
                    calculations();  // 执行计算
                    if (ifReallyDecimal()) {
                        t2.setText((int) val1 + "+");  // 显示计算结果（整数形式）加上加号
                    } else {
                        t2.setText(val1 + "+");  // 显示计算结果加上加号
                    }
                    t1.setText(null);  // 清空t1中的文本
                } else if (t1.getText().length() == 0 && t2.getText().length() > 0) {
                    // t1为空，t2有内容
                    int l = t2.getText().toString().length() - 1;
                    if (ACTION == ADD || ACTION == DIV || ACTION == SUB || ACTION == MUL || ACTION == POW || ACTION == REV) {
                        // 上一个操作为加、除、减、乘、开根号或反转
                        t2.setText(t2.getText().toString().substring(0, l) + "+");  // 替换最后一个字符为加号
                        ACTION = ADD;  // 设置操作为加法
                        return;
                    }
                    if (t2.getText().toString().charAt(l) == '+' || t2.getText().toString().charAt(l) == '/' ||
                            t2.getText().toString().charAt(l) == '*' || t2.getText().toString().charAt(l) == '-' ||
                            t2.getText().toString().charAt(l) == '^' || t2.getText().toString().charAt(l) == 'r') {
                        // 上一个操作为加法、除法、乘法、减法、正负反转或开根号
                        t2.setText(t2.getText().toString());  // 不做任何修改
                        return;
                    }

                    t2.setText(t2.getText().toString() + "+");  // 在t2末尾添加加号
                } else if (t1.getText().length() == 0) {
                    // t1为空
                    t2.setText("Error");  // 显示错误消息
                } else if (ACTION != '0') {
                    // 当前操作不为'0'
                    calculations();  // 执行计算
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "+");  // 显示计算结果（整数形式）加上加号
                    } else {
                        t2.setText((int) val1 + "+");  // 显示计算结果加上加号
                    }
                    t1.setText(null);  // 清空t1中的文本
                    ACTION = ADD;  // 设置操作为加法
                    return;
                }
            }
        });



        b_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t1.getText().length() > 0 && (ACTION == SIN || ACTION == REV || ACTION == POW)) {
                    // 检查当前操作是否为正弦、反转或开根号
                    int l = t1.getText().length();
                    if (t1.getText().toString().charAt(l - 1) == '-') {
                        // 如果t1最后一个字符是减号，则直接返回，不执行后续操作
                        t2.setText(t2.getText());
                        t1.setText(t1.getText());
                        return;
                    }

                    calculations2(); // 执行计算
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "-"); // 在t2中显示计算结果后的减号
                    } else {
                        t2.setText((int) val1 + "-"); // 在t2中显示计算结果后的减号（整数形式）
                    }
                    t1.setText(null); // 清空t1中的文本
                    ACTION = SUB; // 将操作设置为减法
                } else if (t1.getText().length() > 0 && t1.getText().toString().charAt(0) == '-')
                    t1.setText(t1.getText());
                else if (t1.getText().length() == 0 && (ACTION == SIN || ACTION == REV || ACTION == POW)) {
                    if (ACTION == SIN) {
                        t2.setText("sin -"); // 在t2中显示sin操作后的减号
                        t1.setText("-" + t1.getText().toString() + "");
                        return;
                    }
                } else if (t1.getText().length() == 0 && t2.getText().length() > 0) {
                    int l = t2.getText().toString().length() - 1;
                    if (ACTION == ADD || ACTION == DIV || ACTION == MUL ||  ACTION == POW) {
                        t2.setText(t2.getText().toString().substring(0, l) + "-"); // 在t2中显示上一个操作后的减号
                        ACTION = SUB; // 将操作设置为减法
                        return;
                    }
                    if (t2.getText().toString().charAt(l) == '-') {
                        t1.setText("-" + t1.getText().toString()); // 在t1中添加负号
                    } else
                        t2.setText(t2.getText().toString() + "-"); // 在t2中追加减号
                } else if (t1.getText().length() == 0) {
                    ACTION = SUB;
                    t1.setText("-" + t1.getText().toString()); // 在t1中添加负号
                } else if (ACTION != '0') {
                    calculations(); // 执行计算
                    if (t1.getText().length() > 0)
                        if (!ifReallyDecimal()) {
                            t2.setText(val1 + "-"); // 在t2中显示计算结果后的减号
                        } else {
                            t2.setText((int) val1 + "-"); // 在t2中显示计算结果后的减号（整数形式）
                        }
                    t1.setText(null); // 清空t1中的文本
                    ACTION = SUB; // 将操作设置为减法
                } else if (t1.getText().length() > 0) {
                    ACTION = SUB;
                    calculations(); // 执行计算
                    if (t1.getText().length() > 0)
                        if (!ifReallyDecimal()) {
                            t2.setText(val1 + "-"); // 在t2中显示计算结果后的减号
                        } else {
                            t2.setText((int) val1 + "-"); // 在t2中显示计算结果后的减号（整数形式）
                        }
                    t1.setText(null); // 清空t1中的文本
                } else {
                    t2.setText("Error"); // 在t2中显示错误消息
                }
            }
        });


        b_multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ACTION == SIN || ACTION == REV || ACTION == POW) {
                    calculations2();
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "*");
                    } else {
                        t2.setText((int) val1 + "*");
                    }
                    t1.setText(null);
                    ACTION = MUL;
                } else if (t1.getText().length() > 0) {
                    ACTION = MUL;
                    calculations();
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "*");
                    } else {
                        t2.setText((int) val1 + "*");
                    }
                    t1.setText(null);
                } else if (t1.getText().length() == 0 && t2.getText().length() > 0) {
                    int l = t2.getText().toString().length() - 1;
                    if (ACTION == ADD || ACTION == DIV || ACTION == SUB || ACTION == MUL  || ACTION == POW) {
                        t2.setText(t2.getText().toString().substring(0, l) + "*");
                        ACTION = MUL;
                        return;
                    }
                    if (t2.getText().toString().charAt(l) == '^' || t2.getText().toString().charAt(l) == '+' || t2.getText().toString().charAt(l) == '/' || t2.getText().toString().charAt(l) == '*' || t2.getText().toString().charAt(l) == '%') {
                        t2.setText(t2.getText().toString());
                        return;
                    }
                    t2.setText(t2.getText().toString() + "*");

                } else if (t1.getText().length() == 0) {
                    t2.setText("Error");
                } else if (ACTION != '0') {

                    calculations();
                    if (!ifReallyDecimal()) {
                        t2.setText(val1 + "*");
                    } else {
                        t2.setText((int) val1 + "*");
                    }
                    t1.setText(null);
                    ACTION = MUL;


                    return;
                }

            }
        });

        b_equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (t2.getText().length() != 0 && t1.getText().length() == 0) {
                        t2.setText(t2.getText());
                        return;
                    }
                    if (ACTION == SIN || ACTION == REV || ACTION == POW) {
                        calculations2();
                        t2.setText(String.valueOf(val1));
                        return;
                    }
                    if (t1.getText().length() > 0) {
                        calculations();
                        ACTION = EQU;
                        if (!ifReallyDecimal()) {
                            t2.setText(String.valueOf(val1));
                        } else {
                            t2.setText(String.valueOf((int) val1));
                        }
                        t1.setText(null);
                    } else if (t2.getText().length() > 0) {

                        calculations();
                        ACTION = EQU;
                        if (!ifReallyDecimal()) {
                            t2.setText(String.valueOf(val1));
                        } else {
                            t2.setText(String.valueOf((int) val1));
                        }
                        t1.setText(null);
                    } else if (t1.getText().length() == 0) {
                        t2.setText("Error");
                    }
                } catch (Exception e) {
                    if (!(t2.getText().toString().isEmpty())) {
                        t2.setText(t2.getText().toString());
                    }
                    if (!(t1.getText().toString().isEmpty())) {
                        t2.setText(t1.getText().toString());
                        return;
                    }

                }
            }
        });

        b_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t1.getText().length() > 0) {
                    CharSequence name = t1.getText().toString();
                    t1.setText(name.subSequence(0, name.length() - 1));
                } else {
                    val1 = Double.NaN;
                    val2 = Double.NaN;
                    t1.setText("");
                    t2.setText("");
                }
            }
        });


        b_clear.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                val1 = Double.NaN;
                val2 = Double.NaN;
                t1.setText("");
                t2.setText("");
                return true;
            }
        });

    }

    private void idfinder() {
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        b9 = findViewById(R.id.button9);
        b0 = findViewById(R.id.button0);

        sin = findViewById(R.id.sin);
        rev = findViewById(R.id.button_rev);
        pow = findViewById(R.id.pow);

        b_equal = findViewById(R.id.button_equal);
        b_multi = findViewById(R.id.button_multi);
        b_divide = findViewById(R.id.button_divide);
        b_add = findViewById(R.id.button_add);
        b_sub = findViewById(R.id.button_sub);
        b_clear = findViewById(R.id.button_clear);
        b_dot = findViewById(R.id.button_dot);

        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);

    }

    private void calculations() {
        // 检查val1是否为非数字
        if (!Double.isNaN(val1)) {
            // 检查t1是否为空并且t2不为空
            if (t1.getText().length() == 0 && t2.getText().length() > 0) {
                int l = t2.getText().toString().length() - 1;
                val2 = Double.parseDouble(t2.getText().toString().substring(0, l));
            }
            // 检查t1和t2是否都不为空
            else if (t1.getText().length() > 0 && t2.getText().length() > 0) {
                int l = t2.getText().toString().length() - 1;
                val2 = Double.parseDouble(t2.getText().toString().substring(0, l));
                val1 = Double.parseDouble(t1.getText().toString());
                ACTION = t2.getText().toString().charAt(l);
            } else
                val2 = Double.parseDouble(t1.getText().toString());

            // 根据ACTION的值执行相应的计算操作
            switch (ACTION) {
                case ADD:
                    val1 = val1 + val2;
                    break;
                case SUB:
                    val1 = val2 - val1;
                    break;
                case MUL:
                    val1 = val1 * val2;
                    break;
                case DIV:
                    val1 = val2 / val1;
                    break;
                case EXTRA:
                    val1 = (-1) * val1;
                    break;
//
                case EQU:
                    break;
            }
        } else {
            val1 = Double.parseDouble(t1.getText().toString());
        }
    }

    public void calculations2() {
        // 检查t1是否为空
        if (t1.getText().toString().equals(""))
            return;
        val2 = Double.parseDouble(t1.getText().toString());

        // 检查ACTION和val2的值是否满足特定条件


        double b = Math.toRadians(val2);
        int decimalpoint = 4;

        // 根据ACTION的值执行相应的计算操作
        switch (ACTION) {
//            正负反转
            case REV:
                val1 = val2*(-1);
                t1.setText("0");
                break;
//                开方
            case POW:
                val1 = Math.sqrt(val2);
                if(val2<0){
                    Toast.makeText(MainActivity.this,
                            "被开方数字不能为负",
                            Toast.LENGTH_SHORT).show();
                    break;
                }
                t1.setText("0");
                break;

            case SIN:
                val1 = Math.sin(val2);
                val1 = val1 * Math.pow(10, decimalpoint);
                val1 = Math.floor(val1);
                val1 = val1 / Math.pow(10, decimalpoint);
                t1.setText("0");
                break;

        }
    }

    private void ifErrorOnOutput() {
        // 检查t2的文本内容是否为"Error"，如果是，则清空文本内容
        if (t2.getText().toString().equals("Error")) {
            t2.setText("");
        }
    }

    private void noOperation() {
        String inputExpression = t2.getText().toString();

        // 检查输入表达式是否非空且不为"Error"
        if (!inputExpression.isEmpty() && !inputExpression.equals("Error")) {
            // 检查输入表达式是否包含特定运算符，如果包含，则移除该运算符并更新val1的值
            if (inputExpression.contains("-")) {
                inputExpression = inputExpression.replace("-", "");
                t2.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("+")) {
                inputExpression = inputExpression.replace("+", "");
                t2.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("/")) {
                inputExpression = inputExpression.replace("/", "");
                t2.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("%")) {
                inputExpression = inputExpression.replace("%", "");
                t2.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("×")) {
                inputExpression = inputExpression.replace("×", "");
                t2.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
        }
    }

    private boolean ifReallyDecimal() {
        // 检查val1是否为整数
        return val1 == (int) val1;
    }

    private void exceedLength() {
        // 检查t1的文本长度是否超过10个字符，如果超过，则设置文本字体大小为20
        if (t1.getText().toString().length() > 10) {
            t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        }
    }
}